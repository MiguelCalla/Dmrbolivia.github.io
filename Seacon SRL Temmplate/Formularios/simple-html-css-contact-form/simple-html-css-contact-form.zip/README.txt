A Pen created at CodePen.io. You can find this one at https://codepen.io/colorlib/pen/KVoZyv.

 Clean and minimal HTML/CSS contact form with minimal styling to be used on websites, templates and elsehwere. 